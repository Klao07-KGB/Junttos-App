package com.example.junttos.helper;

import com.example.junttos.model.Publicacao;

import java.util.List;

public interface PublicacaoInterface {

    public boolean salvarPublicacao(Publicacao publicacao);
    public boolean atualizarPublicacao(Publicacao publicacao);
    public boolean deletarPublicacao(Publicacao publicacao);
    public List<Publicacao> listarPublicacao();
    public List<Publicacao> listarPublicacao(int idUsuario);
}
