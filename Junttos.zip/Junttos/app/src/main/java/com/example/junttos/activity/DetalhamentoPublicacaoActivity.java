package com.example.junttos.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.junttos.R;
import com.example.junttos.Util.Funcao;
import com.example.junttos.model.Publicacao;

import java.util.List;

public class DetalhamentoPublicacaoActivity extends AppCompatActivity {
    private Publicacao publicAtualDetalhamento;
    private TextView tituloDetalhe, informacaoDetalhe, observacaoDetalhe, periodoDetalhe,acessoDetalhe ;
    private ImageView imageDetalhe;
    public Button butAcesso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhamento_publicacao);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        inicializarComponentes();


        // passando os valores caso seja edicao
        publicAtualDetalhamento = (Publicacao) getIntent().getSerializableExtra("detalhePublicSelecionada");
        recuperarDadosDetalhamento(publicAtualDetalhamento);



        butAcesso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView acesso = (TextView) findViewById(R.id.textViewAcessoDetalhePublic);
                String link = acesso.getText().toString();

                // Build the intent
                Uri webpage  = Uri.parse(link);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, webpage );

                // Verify it resolves
                PackageManager packageManager = getPackageManager();
                List<ResolveInfo> activities = packageManager.queryIntentActivities(mapIntent, 0);
                boolean isIntentSafe = activities.size() > 0;

                // Start an activity if it's safe
                if (isIntentSafe) {
                    startActivity(mapIntent);
                }


            }
        });
    }

    public void recuperarDadosDetalhamento(Publicacao publicAtual) {
// configurar os campos
        if (publicAtual != null) {

            tituloDetalhe.setText(publicAtual.getTitulo_publicacao());
            periodoDetalhe.setText(publicAtual.getDataInicio_publicacao()+" - "+publicAtual.getDataFim_publicacao())  ;
            informacaoDetalhe.setText(publicAtual.getInformacao_publicacao());
           // dataFimPublicacao.setText(publicAtual.getDataFim_publicacao());
             acessoDetalhe.setText(publicAtual.getAcesso_publicacao());
            observacaoDetalhe.setText(publicAtual.getObservacao_publicacao());

            if(!publicAtual.getCaminhoFoto_publicacao().trim().equals("")){
                Bitmap bitmap = new Funcao().StringToBitMap(publicAtual.getCaminhoFoto_publicacao());
                imageDetalhe.setImageBitmap(bitmap);
                imageDetalhe.setTag(bitmap);
            }
        }
    }

    public void inicializarComponentes() {

        tituloDetalhe = findViewById(R.id.textViewTituloDetalhePublic);
        informacaoDetalhe = findViewById(R.id.textViewInformacaooDetalhePublic);
        periodoDetalhe = findViewById(R.id.textViewPeriodoDetalhePublic);
       acessoDetalhe = findViewById(R.id.textViewAcessoDetalhePublic);
        observacaoDetalhe = findViewById(R.id.textViewObservacaoDetalhePublic);
        imageDetalhe = findViewById(R.id.imageViewDetalhePublic);
        butAcesso = findViewById(R.id.butAcesso);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case  android.R.id.home:
                finish();
                break;
        }

        return true;
    }
}
