package com.example.junttos.fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.junttos.R;
import com.example.junttos.activity.DetalhamentoPublicacaoActivity;
import com.example.junttos.activity.ListarPublicacaoUsuarioActivity;
import com.example.junttos.activity.PublicacaoCadastroActivity;
import com.example.junttos.adapter.AdapterListaPublicacao;
import com.example.junttos.adapter.AdapterPesquisa;
import com.example.junttos.helper.PublicacaoDAO;
import com.example.junttos.helper.RecyclerItemClickListener;
import com.example.junttos.helper.SQLite;
import com.example.junttos.model.Publicacao;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class PesquisaFragment extends Fragment {

    private SearchView searchViewPesquisa;
    private RecyclerView recyclerViewPesquisa;
    public static SQLite sqLite;
    public static AdapterPesquisa adapterPesquisa;
    private List<Publicacao> listPublicacao;
    private Publicacao detalhePublicSelecionada;
    private SQLiteDatabase lerDados;
    public PesquisaFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_pesquisa, container, false);
        //  sqLite = new SQLite(getActivity(), "JUNTTOS.sqlite",null, 3);

        // trabalhando em fragment precisa usar view para acessar
        recyclerViewPesquisa = view.findViewById(R.id.recyclerViewPesquisa);

        //configuracoes iniciais
        listPublicacao = new ArrayList<>();


        PublicacaoDAO publicDAO = new PublicacaoDAO(getContext());
        final List<Publicacao> listPublicacao = publicDAO.listarPublicacao();


// configurando o recyclerview
        recyclerViewPesquisa.setHasFixedSize(true);
        recyclerViewPesquisa.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapterPesquisa = new AdapterPesquisa(listPublicacao, getActivity());
        recyclerViewPesquisa.setAdapter(adapterPesquisa);


        recyclerViewPesquisa.addOnItemTouchListener(new RecyclerItemClickListener(
                        getContext(),
                        recyclerViewPesquisa,
                        new RecyclerItemClickListener.OnItemClickListener() {
                            @Override
                            public void onItemClick(View view, int position) {
                                Publicacao detalhePublicSelecionada = listPublicacao.get(position);

                                //enviar para activity
                                Intent intent = new Intent(getContext(), DetalhamentoPublicacaoActivity.class);
                                intent.putExtra("detalhePublicSelecionada", detalhePublicSelecionada);
                                startActivity(intent);

                            }

                            @Override
                            public void onLongItemClick(View view, int position) {

                            }

                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            }
                        }

        ));



        /*
        // configurar o searchView
        searchViewPesquisa.setQueryHint("Busca Publicação");
        searchViewPesquisa.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                // limpandoa  lista
                listPublicacao.clear();

                // validando se existe algum valor na string para poder pesquisar a publicacao
                if (query.length() > 0) {
                        carregarListaPublicacao(query);

                    } else{
                        Toast.makeText(getContext(),"Nenhum valor de pesquisa foi informado.",Toast.LENGTH_SHORT).show();
                    }
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        */


 /*       searchViewPesquisa.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            // capiturando o que é digitado quando clicar em pesquisar
            public boolean onQueryTextSubmit(String query) {
                 // limpandoa  lista
                listPublicacao.clear();

                // validando se existe algum valor na string para poder pesquisar a publicacao
                if (query.length() > 0) {

                    String consultaPesquisa = "SELECT public_titulo FROM PUBLICACAO WHERE public_titulo = " + query.toUpperCase();         // pegando retorno da cosulta

                /*    Cursor cursor = sqLite.getData(consultaPesquisa);

                    if (cursor != null) {
                        cursor.moveToFirst();
                        while (cursor.moveToNext()) {
                            Publicacao pu = new Publicacao();
                            pu.setTitulo_publicacao(cursor.getString(0));
                            listPublicacao.add(pu);
                        }
                    }
                }
                    adapterPesquisa.notifyDataSetChanged();
                }   return true;

    }

            @Override
            // capiturando o que é digitado em tempo real
            public boolean onQueryTextChange(String newText) {

                return false;
            }

        });
*/
        return view;
    }

    /*
    public void carregarListaPublicacao(String valorBusca){


        List<Publicacao> publicListPorValorBusca = new ArrayList<>();

        String sql = "SELECT * FROM " + SQLite.TABELA_PUBLICACAO + " WHERE public_titulo LIKE " + "%"+valorBusca+"%" + ";";
        Cursor cursor = lerDados.rawQuery(sql, null);

        while(cursor.moveToNext()) {

            Publicacao publicacao = new Publicacao();

            int id = cursor.getInt(cursor.getColumnIndex("public_id"));
            String titulo = cursor.getString(cursor.getColumnIndex("public_titulo"));
            String informacao = cursor.getString(cursor.getColumnIndex("public_informacao"));
            String datInicio = cursor.getString(cursor.getColumnIndex("public_dataInicio"));
            String datFim = cursor.getString(cursor.getColumnIndex("public_dataFim"));
            String acesso = cursor.getString(cursor.getColumnIndex("public_acesso"));
            String observacao = cursor.getString(cursor.getColumnIndex("public_observacao"));
            int idUsu = cursor.getInt(cursor.getColumnIndex("public_idUsuario"));


            publicacao.setId_publicacao(id);
            publicacao.setTitulo_publicacao(titulo);
            publicacao.setInformacao_publicacao(informacao);
            publicacao.setDataInicio_publicacao(datInicio);
            publicacao.setDataFim_publicacao(datFim);
            publicacao.setAcesso_publicacao(acesso);
            publicacao.setObservacao_publicacao(observacao);
            publicacao.setidUsuario_publicacao(idUsu);

            publicListPorValorBusca.add(publicacao);

        }
            PublicacaoDAO publicDAO = new PublicacaoDAO(getContext());
            listPublicacao = publicDAO.listarPublicacao();

            //exibindo

            //configurar adapter
            adapterPesquisa = new AdapterPesquisa(listPublicacao, getActivity());

    }
    */

    @Override
    public void onStart() {
       // carregarListaPublicacao();
        super.onStart();
    }
}

