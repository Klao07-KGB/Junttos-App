package com.example.junttos.model;

public class Usuario {

    private int usu_id ;
    private String usu_matricula;
    private String usu_senha;
    private int usu_tipo;


    public Usuario() {

    }

    public int getUsu_id() {
        return usu_id;
    }

    public void setUsu_id(int usu_id) {
        this.usu_id = usu_id;
    }

    public String getUsu_matricula() {
        return usu_matricula;
    }

    public void setUsu_matricula(String usu_matricula) {
        this.usu_matricula = usu_matricula;
    }

    public String getUsu_senha() {
        return usu_senha;
    }

    public void setUsu_senha(String usu_senha) {
        this.usu_senha = usu_senha;
    }

    public int getUsu_tipo() {
        return usu_tipo;
    }

    public void setUsu_tipo(int usu_tipo) {
        this.usu_tipo = usu_tipo;
    }
}
