package com.example.junttos.activity;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.junttos.R;
import com.example.junttos.fragment.PesquisaFragment;
import com.example.junttos.helper.SQLite;
import com.example.junttos.model.Publicacao;
import com.example.junttos.model.Usuario;

public class LoginActivity extends AppCompatActivity {
    public static int tipo = 0;
    public  static int identUsuario = 0;
    private EditText matriculaLogin, senhaLogin;
    private Button bentrarLogin;
    private ProgressBar progressLogin;

    public static SQLite sqLite;
    private MenuItem menu;


    private Usuario usuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        //verificando se tabela existe e qualquer coisa insere
        sqLite = new SQLite(LoginActivity.this);

        // alimenatndo tabela usuarios
        //tipo 1 aluno, 2 professor

       if (sqLite.emptyLogin()) {
           sqLite.insertlogin("205181021", "12345678", 2);
           sqLite.insertlogin("205181201", "10815021", 1);
       }

/*
  // verificando se o banco está criado
        boolean b = sqLite.doesDatabaseExist(LoginActivity.this, "JUNTTOS.sqlite");
        Toast.makeText(LoginActivity.this,"retorno: "+b,Toast.LENGTH_SHORT).show();
*/

        // inicializando os componetes
        inicializarComponentes();

        bentrarLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                // pegando valores dos componentes
                String textMatricula = matriculaLogin.getText().toString();
                String textSenha = senhaLogin.getText().toString();

                //validando campos de matricula e senha
                if (textMatricula.length() > 0) {
                    if (textSenha.length() > 0) {

                      progressLogin.setVisibility(View.VISIBLE);

                        usuario = new Usuario();
                        // Cariação do SQLiteDatabase a leitura do banco de dados
                        String consultaAutentificacao ="SELECT usu_id,usu_matricula,usu_senha,usu_tipo FROM USUARIO WHERE usu_matricula ="+textMatricula+" AND usu_senha = "+textSenha;

                        try {
                            // pegando retorno da cosulta
                            Cursor cursor = sqLite.getData(consultaAutentificacao);


                            // indices detabela
                            int indiceTipo = cursor.getColumnIndex("usu_tipo");

                            cursor.moveToFirst();

                            // verifica se o cursos retornou alguma resultado
                            if (cursor != null) {

                                if (cursor.getCount() > 0) {


                                   identUsuario = getIdentificador();
                                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    // caso não retornar nenhum usuario do cursor, o retorno da função será nula
                                   progressLogin.setVisibility(View.GONE);
                                    Toast.makeText(LoginActivity.this, "Matrícula ou senha incorretos", Toast.LENGTH_SHORT).show();

                                }

                                cursor.moveToNext();
                            }


                            sqLite.close();
                            matriculaLogin.setText("");
                            senhaLogin.setText("");


                        }catch (Exception e){
                            e.printStackTrace();
                        }
                        } else {
                            Toast.makeText(LoginActivity.this, "Preencha a senha!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(LoginActivity.this, "Preencha a matricula!", Toast.LENGTH_SHORT).show();
                    }
                }

        });






    }


    public int getIdentificador(){
        int identificador = 0;
        String mat =   matriculaLogin.getText().toString();

        // Cariação do SQLiteDatabase a leitura do banco de dados
        String consultaIdentificador ="SELECT usu_id,usu_matricula,usu_senha,usu_tipo FROM USUARIO WHERE usu_matricula ="+mat;
        try {
            // pegando retorno da cosulta
            Cursor cursor = sqLite.getData(consultaIdentificador);


            // indices detabela
            int id = cursor.getColumnIndex("usu_id");

            cursor.moveToFirst();

            // verifica se o cursos retornou alguma resultado
            if (cursor != null) {

                if (cursor.getCount() > 0) {

                    identificador = cursor.getInt(id);
                }
                cursor.moveToNext();
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return identificador;
    }
 public static int getRetornoTipoUsuario(int ident){


     // Cariação do SQLiteDatabase a leitura do banco de dados
     String consultaTipo ="SELECT usu_id,usu_matricula,usu_senha,usu_tipo FROM USUARIO WHERE usu_id ="+ident;

     try {
         // pegando retorno da cosulta
         Cursor cursor = sqLite.getData(consultaTipo);


         // indices detabela
         int iT = cursor.getColumnIndex("usu_tipo");

         cursor.moveToFirst();

         // verifica se o cursos retornou alguma resultado
         if (cursor != null) {

             if (cursor.getCount() > 0) {

                 tipo = cursor.getInt(iT);
             }
             cursor.moveToNext();
         }
     }catch (Exception e){
         e.printStackTrace();
     }
   return tipo;
 }

    // metodo de inicializar compoenetes do cadastro da publicacao
    public void inicializarComponentes(){

        matriculaLogin = findViewById(R.id.editMatriculaLogin);
        senhaLogin = findViewById(R.id.editSenhaLogin);
        bentrarLogin = findViewById(R.id.butEntrarLogin);
        progressLogin = findViewById(R.id.progressBarLogin);

    }


}
