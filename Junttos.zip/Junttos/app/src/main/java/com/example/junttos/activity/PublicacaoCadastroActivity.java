package com.example.junttos.activity;


import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.junttos.R;
import com.example.junttos.Util.Funcao;
import com.example.junttos.helper.PublicacaoDAO;
import com.example.junttos.helper.SQLite;
import com.example.junttos.model.Publicacao;

import java.util.Calendar;

public class PublicacaoCadastroActivity extends AppCompatActivity {

    private EditText tituloPublicacao, informacaoPublicacao, observacaoPublicacao, dataInicioPublicacao, dataFimPublicacao, acessoPublicacao;
    private ProgressBar progressCadastroPublicacao;
    private ImageView imagePublicacao;

    public static SQLite sqLite;


    private String[] permissaoGaleria = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    private static final int SELECAO_GALERIA = 200;
    private int identificador = 0;

    private Publicacao publicAtual;
    public int idPublicacao, identUsuario;

    private String diaSelectDate, mesSelectDate, anoSelectDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publicacao_cadastro);

        identUsuario = LoginActivity.identUsuario;


        // configurando o toolbar
        //Toolbar toolbar = findViewById(R.id.toolbarPrincipal);
        //toolbar.setTitle("Cadastrar Publicação");
        //setSupportActionBar(toolbar);

        // buttao de voltar

        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close_black);

        idPublicacao = 0;

        inicializarComponentes();
        // passando os valores caso seja edicao
        publicAtual = (Publicacao) getIntent().getSerializableExtra("publicselecionada");
        recuperarDadosEdicao(publicAtual);


        //abrir galeria
        imagePublicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                if (i.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(i, SELECAO_GALERIA);
                }
            }
        });


        // cadastro da publicacao
        // esconder o progess bar
        progressCadastroPublicacao.setVisibility(View.GONE);

    }


    private void Confirmar() {

        progressCadastroPublicacao.setVisibility(View.VISIBLE);

        // pegando valores dos componentes
        String textTitulo = tituloPublicacao.getText().toString();
        String textInformacao = informacaoPublicacao.getText().toString();
        String textDataInicio = dataInicioPublicacao.getText().toString();
        String textDataFim = dataFimPublicacao.getText().toString();
        String textAcesso = acessoPublicacao.getText().toString();
        String textObservacao = observacaoPublicacao.getText().toString();

        //byte[] imagem = imageViewToByte(imagePublicacao);

        String imagem = "";
        try { imagem = new Funcao().BitmapToString((Bitmap)imagePublicacao.getTag()); }
        catch(Exception e){ imagem = ""; }

        int textidUsuario = identUsuario;


        if (textTitulo.isEmpty()) {
            progressCadastroPublicacao.setVisibility(View.GONE);
            Toast.makeText(PublicacaoCadastroActivity.this, "Favor informar o título!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (textTitulo.isEmpty()) {
            progressCadastroPublicacao.setVisibility(View.GONE);
            Toast.makeText(PublicacaoCadastroActivity.this, "Favor informar informações!", Toast.LENGTH_SHORT).show();
            return;
        }

        // instanciando a publicacao
        Publicacao publicacao = new Publicacao();
        publicacao.setId_publicacao(idPublicacao);
        publicacao.setTitulo_publicacao(textTitulo);
        publicacao.setInformacao_publicacao(textInformacao);
        publicacao.setDataInicio_publicacao(textDataInicio);
        publicacao.setDataFim_publicacao(textDataFim);
        publicacao.setAcesso_publicacao(textAcesso);
        publicacao.setObservacao_publicacao(textObservacao);
        publicacao.setCaminhoFoto_publicacao(imagem);
        publicacao.setidUsuario_publicacao(textidUsuario);

        PublicacaoDAO publicDAO = new PublicacaoDAO(getApplicationContext());


        if (publicAtual != null) {

            if (publicDAO.atualizarPublicacao(publicacao)) {
                Toast.makeText(PublicacaoCadastroActivity.this, "Publicação salvar com sucesso!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(PublicacaoCadastroActivity.this, "Erro ao salvar publicação!", Toast.LENGTH_SHORT).show();
            }

        } else {

            if (publicDAO.salvarPublicacao(publicacao)) {
                Toast.makeText(PublicacaoCadastroActivity.this, "Publicação salvar com sucesso!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(PublicacaoCadastroActivity.this, "Erro ao salvar publicação!", Toast.LENGTH_SHORT).show();

            }
        }

        progressCadastroPublicacao.setVisibility(View.GONE);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            Bitmap imagem = null;

            try {
                switch (requestCode) {
                    case SELECAO_GALERIA:
                        Uri localDaImagem = data.getData();
                        imagem = MediaStore.Images.Media.getBitmap(getContentResolver(), localDaImagem);
                        break;
                }
                if (imagem != null) {
                    imagePublicacao.setImageBitmap(imagem);
                    imagePublicacao.setTag(imagem);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // metodo cadastrar publicacao
    public void cadastrar(Publicacao publicacao) {
        // exibir o progress bar
        progressCadastroPublicacao.setVisibility(View.VISIBLE);
        try {


            // limpando os campos
            tituloPublicacao.setText("");
            informacaoPublicacao.setText("");
            dataInicioPublicacao.setText("");
            dataFimPublicacao.setText("");
            acessoPublicacao.setText("");
            observacaoPublicacao.setText("");
            imagePublicacao.setImageResource(0);
            imagePublicacao.setTag("0");
          //  publicImagem.setImageResource(R.drawable.addpublicacao);
            progressCadastroPublicacao.setVisibility(View.GONE);
        } catch (Exception e) {
            e.printStackTrace();
            progressCadastroPublicacao.setVisibility(View.GONE);
        }

    }

    public void recuperarDadosEdicao(Publicacao publicAtual) {
// configurar os campos
        if (publicAtual != null) {
            idPublicacao = publicAtual.getId_publicacao();
            tituloPublicacao.setText(publicAtual.getTitulo_publicacao());
            informacaoPublicacao.setText(publicAtual.getInformacao_publicacao());
            dataInicioPublicacao.setText(publicAtual.getDataInicio_publicacao());
            dataFimPublicacao.setText(publicAtual.getDataFim_publicacao());
            acessoPublicacao.setText(publicAtual.getAcesso_publicacao());
            observacaoPublicacao.setText(publicAtual.getObservacao_publicacao());

            if(!publicAtual.getCaminhoFoto_publicacao().trim().equals("")){
                Bitmap bitmap = new Funcao().StringToBitMap(publicAtual.getCaminhoFoto_publicacao());
                imagePublicacao.setImageBitmap(bitmap);
                imagePublicacao.setTag(bitmap);
            }
        }
    }


    // metodo de inicializar compoenetes do cadastro da publicacao
    public void inicializarComponentes() {

        tituloPublicacao = findViewById(R.id.editTituloPulicacao);
        informacaoPublicacao = findViewById(R.id.editInformacaoPulicacao);
        dataInicioPublicacao = findViewById(R.id.editDataInicialPublicacao);
        dataFimPublicacao = findViewById(R.id.editDataFinalPublicacao);
        acessoPublicacao = findViewById(R.id.editAcessoPaginaPulicacao);
        observacaoPublicacao = findViewById(R.id.editObservacaoPulicacao);
        progressCadastroPublicacao = findViewById(R.id.progressBarLogin);
        imagePublicacao = findViewById(R.id.imageViewPublicacao);


        dataInicioPublicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSelectDate(v, 1);
            }
        });

        dataFimPublicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSelectDate(v, 2);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_publicacao, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.action_publicacao_confirmar:
                Confirmar();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    private void getSelectDate(View v, final int field) {

        View view = getLayoutInflater().inflate(R.layout.get_date, null);

        AlertDialog.Builder builderDate = new AlertDialog.Builder(v.getContext());
        builderDate.setView(view);

        DatePicker datePicker = (DatePicker) view.findViewById(R.id.datePicker);
        datePicker.setMinDate(Calendar.getInstance().getTimeInMillis());

        Calendar calendar = Calendar.getInstance();
        anoSelectDate = String.valueOf(calendar.get(Calendar.YEAR));
        mesSelectDate = String.valueOf(calendar.get(Calendar.MONTH));
        diaSelectDate = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));

        diaSelectDate = "0" + diaSelectDate;

        int conversao = Integer.parseInt(mesSelectDate)+1;
        mesSelectDate = String.valueOf(conversao);
        mesSelectDate = "0" + (mesSelectDate);

        try{
            diaSelectDate = diaSelectDate.substring(1,3);
        }
        catch (Exception e){

        }

        try{
            mesSelectDate = mesSelectDate.substring(1,3);
        }
        catch (Exception e){

        }

        if (field == 1) {
            if (!dataInicioPublicacao.getText().toString().trim().equals("")) {
                diaSelectDate = dataInicioPublicacao.getText().toString().substring(0, 2);
                mesSelectDate = dataInicioPublicacao.getText().toString().substring(3, 5);
                anoSelectDate = dataInicioPublicacao.getText().toString().substring(6, 10);

                int dia = Integer.parseInt(diaSelectDate);
                int mes = Integer.parseInt(mesSelectDate);
                int ano = Integer.parseInt(anoSelectDate);

                datePicker.updateDate(ano, mes-1, dia);
            }
        }

        if (field == 2) {
            if (!dataFimPublicacao.getText().toString().trim().equals("")) {
                diaSelectDate = dataFimPublicacao.getText().toString().substring(0, 2);
                mesSelectDate = dataFimPublicacao.getText().toString().substring(3, 5);
                anoSelectDate = dataFimPublicacao.getText().toString().substring(6, 10);

                int dia = Integer.parseInt(diaSelectDate);
                int mes = Integer.parseInt(mesSelectDate);
                int ano = Integer.parseInt(anoSelectDate);

                datePicker.updateDate(ano, mes-1, dia);
            }
        }

        builderDate.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                dialog.dismiss();
            }
        });

        builderDate.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                if (field == 1) {
                    dataInicioPublicacao.setText(diaSelectDate + "/" + mesSelectDate + "/" + anoSelectDate);
                }

                if (field == 2) {
                    dataFimPublicacao.setText(diaSelectDate + "/" + mesSelectDate + "/" + anoSelectDate);
                }
            }
        });

        datePicker.init(datePicker.getYear(),
                datePicker.getMonth(),
                datePicker.getDayOfMonth(),
                new DatePicker.OnDateChangedListener() {
                    @Override
                    public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                        diaSelectDate = String.valueOf(dayOfMonth);
                        anoSelectDate = String.valueOf(year);
                        diaSelectDate = "0" + diaSelectDate;
                        mesSelectDate = "0" + (monthOfYear + 1);

                        try{
                            diaSelectDate = diaSelectDate.substring(1,3);
                        }
                        catch (Exception e){

                        }

                        try{
                            mesSelectDate = mesSelectDate.substring(1,3);
                        }
                        catch (Exception e){

                        }

                        if (field == 1) {
                            dataInicioPublicacao.setText(diaSelectDate + "/" + mesSelectDate + "/" + anoSelectDate);
                        }

                        if (field == 2) {
                            dataFimPublicacao.setText(diaSelectDate + "/" + mesSelectDate + "/" + anoSelectDate);
                        }
                    }
                });


        builderDate.create().show();

    }


}
