package com.example.junttos.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.junttos.model.Publicacao;

import java.util.ArrayList;
import java.util.List;

public class PublicacaoDAO implements PublicacaoInterface {
    private SQLiteDatabase escreverDados;
    private SQLiteDatabase lerDados;
    private String id;
    private String[] args;

    public PublicacaoDAO(Context context) {

        SQLite sqLite = new SQLite(context);
        escreverDados = sqLite.getWritableDatabase();
        lerDados = sqLite.getReadableDatabase();
    }

    @Override
    public boolean salvarPublicacao(Publicacao publicacao) {

        try {
            ContentValues cv = new ContentValues();

            cv.put("public_titulo", publicacao.getTitulo_publicacao());
            cv.put("public_informacao", publicacao.getInformacao_publicacao());
            cv.put("public_dataInicio", publicacao.getDataInicio_publicacao());
            cv.put("public_dataFim", publicacao.getDataFim_publicacao());
            cv.put("public_acesso", publicacao.getAcesso_publicacao());
            cv.put("public_observacao", publicacao.getObservacao_publicacao());
            cv.put("public_imagem", publicacao.getCaminhoFoto_publicacao());
            cv.put("public_idUsuario", publicacao.getidUsuario_publicacao());


            escreverDados.insert(SQLite.TABELA_PUBLICACAO, null, cv);
        } catch (Exception e) {

            return false;
        }
        return true;
    }

    @Override
    public boolean atualizarPublicacao(Publicacao publicacao) {

        try {
            ContentValues cv = new ContentValues();

            cv.put("public_titulo", publicacao.getTitulo_publicacao());
            cv.put("public_informacao", publicacao.getInformacao_publicacao());
            cv.put("public_dataInicio", publicacao.getDataInicio_publicacao());
            cv.put("public_dataFim", publicacao.getDataFim_publicacao());
            cv.put("public_acesso", publicacao.getAcesso_publicacao());
            cv.put("public_observacao", publicacao.getObservacao_publicacao());
            cv.put("public_imagem", publicacao.getCaminhoFoto_publicacao());

            String[] args = {String.valueOf(publicacao.getId_publicacao()), String.valueOf(publicacao.getidUsuario_publicacao())};

            escreverDados.update(SQLite.TABELA_PUBLICACAO, cv, "public_id=? AND public_idUsuario=? ", args);


        } catch (Exception e) {

            return false;
        }
        return true;

    }

    @Override
    public boolean deletarPublicacao(Publicacao publicacao) {
        try {
            String[] args = {String.valueOf(publicacao.getId_publicacao())};

            escreverDados.delete(SQLite.TABELA_PUBLICACAO, "public_id=? ", args);
        } catch (Exception e) {

            return false;
        }
        return true;
    }

    @Override
    public List<Publicacao> listarPublicacao() {
        List<Publicacao> publiclist = new ArrayList<>();

        String sql = "SELECT * FROM " + SQLite.TABELA_PUBLICACAO + " ORDER BY public_id desc;";
        Cursor cursor = lerDados.rawQuery(sql, null);

        while (cursor.moveToNext()) {

            Publicacao publicacao = new Publicacao();

            int id = cursor.getInt(cursor.getColumnIndex("public_id"));
            String titulo = cursor.getString(cursor.getColumnIndex("public_titulo"));
            String informacao = cursor.getString(cursor.getColumnIndex("public_informacao"));
            String datInicio = cursor.getString(cursor.getColumnIndex("public_dataInicio"));
            String datFim = cursor.getString(cursor.getColumnIndex("public_dataFim"));
            String acesso = cursor.getString(cursor.getColumnIndex("public_acesso"));
            String observacao = cursor.getString(cursor.getColumnIndex("public_observacao"));
            int idUsu = cursor.getInt(cursor.getColumnIndex("public_idUsuario"));

            String imagem = cursor.getString(cursor.getColumnIndex("public_imagem"));


            publicacao.setId_publicacao(id);
            publicacao.setTitulo_publicacao(titulo);
            publicacao.setInformacao_publicacao(informacao);
            publicacao.setDataInicio_publicacao(datInicio);
            publicacao.setDataFim_publicacao(datFim);
            publicacao.setAcesso_publicacao(acesso);
            publicacao.setObservacao_publicacao(observacao);
            publicacao.setidUsuario_publicacao(idUsu);
            publicacao.setCaminhoFoto_publicacao(imagem);

            publiclist.add(publicacao);
        }
        return publiclist;
    }

    @Override
    public List<Publicacao> listarPublicacao(int idUsuario) {
        List<Publicacao> publiclist = new ArrayList<>();

        String sql = "SELECT * FROM " + SQLite.TABELA_PUBLICACAO + " where public_idUsuario = " + idUsuario + " ORDER BY public_id desc;";
        Cursor cursor = lerDados.rawQuery(sql, null);

        while (cursor.moveToNext()) {

            Publicacao publicacao = new Publicacao();

            int id = cursor.getInt(cursor.getColumnIndex("public_id"));
            String titulo = cursor.getString(cursor.getColumnIndex("public_titulo"));
            String informacao = cursor.getString(cursor.getColumnIndex("public_informacao"));
            String datInicio = cursor.getString(cursor.getColumnIndex("public_dataInicio"));
            String datFim = cursor.getString(cursor.getColumnIndex("public_dataFim"));
            String acesso = cursor.getString(cursor.getColumnIndex("public_acesso"));
            String observacao = cursor.getString(cursor.getColumnIndex("public_observacao"));
            int idUsu = cursor.getInt(cursor.getColumnIndex("public_idUsuario"));

            String imagem = cursor.getString(cursor.getColumnIndex("public_imagem"));


            publicacao.setId_publicacao(id);
            publicacao.setTitulo_publicacao(titulo);
            publicacao.setInformacao_publicacao(informacao);
            publicacao.setDataInicio_publicacao(datInicio);
            publicacao.setDataFim_publicacao(datFim);
            publicacao.setAcesso_publicacao(acesso);
            publicacao.setObservacao_publicacao(observacao);
            publicacao.setidUsuario_publicacao(idUsu);
            publicacao.setCaminhoFoto_publicacao(imagem);

            publiclist.add(publicacao);
        }
        return publiclist;
    }

}
