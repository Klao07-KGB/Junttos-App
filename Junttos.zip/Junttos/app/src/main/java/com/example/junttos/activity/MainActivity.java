package com.example.junttos.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;

import com.example.junttos.R;
import com.example.junttos.fragment.FeedFragment;
import com.example.junttos.fragment.PesquisaFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

import java.lang.reflect.Field;

public class MainActivity extends AppCompatActivity {
    public int tipoUsuario;
    public  int identUsuario;

    private Menu menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

 identUsuario = LoginActivity.identUsuario;



        //chamando o método
        configurarBottomNavegationView();

        // configurando o fragmento de abertura
        FragmentManager fragmentManager =  getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.viewPager, new FeedFragment()).commit();

    }


    // método para configurar o bottom navegation view
    private void configurarBottomNavegationView(){
       // configuracaoes do botom navigation iniciais
        BottomNavigationViewEx bottNaviView = findViewById(R.id.bott_nave);
        bottNaviView.enableAnimation(true);
        bottNaviView.enableItemShiftingMode(false);
        bottNaviView.enableShiftingMode(false);
        bottNaviView.setTextVisibility(false);

        tipoUsuario = LoginActivity.getRetornoTipoUsuario(identUsuario);
        if(tipoUsuario == 2){
            bottNaviView.getMenu().getItem(2).setVisible(false);
        }else {
            bottNaviView.getMenu().getItem(2).setVisible(true);
        }

        //habilitar navegação dos fragments
   habilitarNavegacao(bottNaviView);

   // configurando item selecionado
        Menu menu = bottNaviView.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);

    }

    //método para tratar click do bottom navigation

    private void habilitarNavegacao(BottomNavigationViewEx viewEx){
     viewEx.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
         @Override
         public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

             FragmentManager fragmentManager =  getSupportFragmentManager();
             FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();



              switch (menuItem.getItemId()){
                case R.id.item_home:
                    menu.getItem(1).setVisible(false);
                    fragmentTransaction.replace(R.id.viewPager, new FeedFragment()).commit();
                    return true;


                 case R.id.item_pesquisa:
                     fragmentTransaction.replace(R.id.viewPager, new PesquisaFragment()).commit();
                     menu.getItem(1).setVisible(true);
                     return true;

                 case R.id.item_publicacao:
                     startActivity(new Intent(getApplicationContext(), ListarPublicacaoUsuarioActivity.class));

                     return true;
            }

             return false;
         }
     });
    }

  @Override
    public boolean onCreateOptionsMenu(Menu menu){

        this.menu = menu;

      getMenuInflater().inflate(R.menu.menu_main, menu);
      getMenuInflater().inflate(R.menu.pesquisar, menu);

      MenuItem menuItem = menu.findItem(R.id.pesquisa);
      SearchView searchView = (SearchView) MenuItemCompat.getActionView(menuItem);

      try {
          AutoCompleteTextView searchTextView = (AutoCompleteTextView) searchView.findViewById(R.id.search_src_text);

          Field mCursorDrawableRes = TextView.class.getDeclaredField("mCursorDrawableRes");
          mCursorDrawableRes.setAccessible(true);
          mCursorDrawableRes.set(searchTextView, R.drawable.cursor_searchview);

      } catch (Exception e) {
      }

      searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
          @Override
          public boolean onQueryTextSubmit(String query) {
              return false;
          }

          @Override
          public boolean onQueryTextChange(String newText) {

              String text = newText;

              try {
                  PesquisaFragment.adapterPesquisa.filter(text);
              }catch (Exception e){

              }
              return false;
          }
      });

      menu.getItem(1).setVisible(false);

      return super.onCreateOptionsMenu(menu);
  }


  //ao selecionar opcap sair do menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_sair:
                deslogar();
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    // metodo para desloga do aplicativo
    private void deslogar(){
       try{
//falta implementar

       }catch (Exception e){
           e.printStackTrace();
       }
    }



}
