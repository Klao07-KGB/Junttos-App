package com.example.junttos.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.junttos.R;
import com.example.junttos.Util.Funcao;
import com.example.junttos.model.Publicacao;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AdapterFeedPublicacao extends RecyclerView.Adapter<AdapterFeedPublicacao.MyViewHolder>{


    private List<Publicacao> listapublicacaoFeed;
    private Context context;

    private ArrayList<Publicacao> arraylist;


    //construtor
    public AdapterFeedPublicacao(List<Publicacao> listap, Context c) {
        this.listapublicacaoFeed = listap;
        this.context = c;
        this.arraylist = new ArrayList<>();
        this.arraylist.addAll(listap);
    }


    @NonNull
    @Override
    public AdapterFeedPublicacao.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemLista = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_feed_publicacao, parent, false);
        return new AdapterFeedPublicacao.MyViewHolder(itemLista);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Publicacao publicacao = listapublicacaoFeed.get(position);
        holder.titulo.setText(publicacao.getTitulo_publicacao());

        if(!publicacao.getCaminhoFoto_publicacao().trim().equals("")){
            Bitmap bitmap = new Funcao().StringToBitMap(publicacao.getCaminhoFoto_publicacao());
            holder.foto.setImageBitmap(bitmap);
        }
    }



    @Override
    public int getItemCount() {
        return listapublicacaoFeed.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView foto;
        TextView titulo;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            foto = itemView.findViewById(R.id.imageViewFeed);
            titulo = itemView.findViewById(R.id.textViewTituloFeed);
        }
    }

    public void filter(String charText) {

        charText = charText.toLowerCase(Locale.getDefault());
        listapublicacaoFeed.clear();

        if (charText.length() == 0) {
            listapublicacaoFeed.addAll(arraylist);
        } else {
            for (Publicacao wp : arraylist) {
                if (wp.getTitulo_publicacao().toLowerCase(Locale.getDefault()).contains(charText)) {
                    listapublicacaoFeed.add(wp);
                }
            }
        }

        notifyDataSetChanged();
    }

}
