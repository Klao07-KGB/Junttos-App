package com.example.junttos.model;

import java.io.Serializable;

public class Publicacao implements Serializable {

    private int id_publicacao;
    private String titulo_publicacao;
    private String informacao_publicacao;
    private String dataInicio_publicacao;
    private String dataFim_publicacao;
    private String acesso_publicacao;
    private String observacao_publicacao;
    private String caminhoFoto_publicacao;
    private int idUsuario_publicacao;

    public Publicacao() {
    }

    public int getId_publicacao() {
        return id_publicacao;
    }

    public void setId_publicacao(int id_publicacao) {
        this.id_publicacao = id_publicacao;
    }

    public String getTitulo_publicacao() {
        return titulo_publicacao;
    }

    public void setTitulo_publicacao(String titulo_publicacao) {
        this.titulo_publicacao = titulo_publicacao.toUpperCase();
    }

    public String getInformacao_publicacao() {
        return informacao_publicacao;
    }

    public void setInformacao_publicacao(String informacao_publicacao) {
        this.informacao_publicacao = informacao_publicacao;
    }

    public String getDataInicio_publicacao() {
        return dataInicio_publicacao;
    }

    public void setDataInicio_publicacao(String dataInicio_publicacao) {
        this.dataInicio_publicacao = dataInicio_publicacao;
    }

    public String getDataFim_publicacao() {
        return dataFim_publicacao;
    }

    public void setDataFim_publicacao(String dataFim_publicacao) {
        this.dataFim_publicacao = dataFim_publicacao;
    }

    public String getAcesso_publicacao() {
        return acesso_publicacao;
    }

    public void setAcesso_publicacao(String acesso_publicacao) {
        this.acesso_publicacao = acesso_publicacao;
    }

    public String getObservacao_publicacao() {
        return observacao_publicacao;
    }

    public void setObservacao_publicacao(String observacao_publicacao) {
        this.observacao_publicacao = observacao_publicacao;
    }

    public String getCaminhoFoto_publicacao() {
        return caminhoFoto_publicacao;
    }

    public void setCaminhoFoto_publicacao(String caminhoFoto_publicacao) {
        this.caminhoFoto_publicacao = caminhoFoto_publicacao;
    }


    public int getidUsuario_publicacao() {
        return idUsuario_publicacao;
    }

    public void setidUsuario_publicacao(int idUsuario) {
        this.idUsuario_publicacao = idUsuario;
    }
}
