package com.example.junttos.Util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import java.io.ByteArrayOutputStream;

public class Funcao {

    public String BitmapToString(Bitmap bitmap){
        ByteArrayOutputStream baos = new  ByteArrayOutputStream();

        if(bitmap.getWidth() > bitmap.getHeight()) {
            float altura = (Float.parseFloat("" + bitmap.getHeight())/Float.parseFloat("" + bitmap.getWidth())) * 1024;
            bitmap = Bitmap.createScaledBitmap(bitmap, 1024, (int)altura, true);
        } else {
            float largura = (Float.parseFloat("" + bitmap.getWidth())/Float.parseFloat("" + bitmap.getHeight())) * 1024;
            bitmap = Bitmap.createScaledBitmap(bitmap, (int)largura, 1024, true);
        }

        try{ bitmap.compress(Bitmap.CompressFormat.JPEG, 40, baos); }
        catch(Exception e){ bitmap.compress(Bitmap.CompressFormat.PNG, 40, baos); }

        byte [] b = baos.toByteArray();
        String temp = Base64.encodeToString(b, Base64.NO_WRAP);
        return temp;
    }

    public Bitmap StringToBitMap(String encodedString){
        try {
            byte [] encodeByte = Base64.decode(encodedString, Base64.NO_WRAP);
            Bitmap bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch(Exception e) {
            e.getMessage();
            return null;
        }
    }

}
