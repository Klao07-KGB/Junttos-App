package com.example.junttos.fragment;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;

import com.example.junttos.R;
import com.example.junttos.activity.DetalhamentoPublicacaoActivity;
import com.example.junttos.adapter.AdapterFeedPublicacao;
import com.example.junttos.adapter.AdapterListaPublicacao;
import com.example.junttos.adapter.AdapterPesquisa;
import com.example.junttos.helper.PublicacaoDAO;
import com.example.junttos.helper.RecyclerItemClickListener;
import com.example.junttos.model.Publicacao;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class FeedFragment extends Fragment {

    private AdapterFeedPublicacao adapterPesquisaFeed;
    private List<Publicacao> listPublicacaoFeed;
    private RecyclerView recyclerViewFeed;


    public FeedFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_feed, container, false);


        recyclerViewFeed = view.findViewById(R.id.recyclerViewFeed);

        //configuracoes iniciais
        listPublicacaoFeed = new ArrayList<>();


        recyclerViewFeed.addOnItemTouchListener(new RecyclerItemClickListener(getContext(), recyclerViewFeed, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Publicacao detalhePublicSelecionada = listPublicacaoFeed.get(position);

                //enviar para activity
                Intent intent = new Intent(getContext(), DetalhamentoPublicacaoActivity.class);
                intent.putExtra("detalhePublicSelecionada", detalhePublicSelecionada);
                startActivity(intent);
            }

            @Override
            public void onLongItemClick(View view, int position) {

            }

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        }));


        return view;
    }




    public void carregarListaPublicacaoUsuario(){

        PublicacaoDAO publicDAO = new PublicacaoDAO(getContext());
        listPublicacaoFeed = publicDAO.listarPublicacao();

        adapterPesquisaFeed = new AdapterFeedPublicacao(listPublicacaoFeed, getContext());

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerViewFeed.setLayoutManager(layoutManager);
        recyclerViewFeed.setHasFixedSize(true);
        recyclerViewFeed.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayout.VERTICAL));
        recyclerViewFeed.setAdapter(adapterPesquisaFeed);

    }

    @Override
    public void onStart() {
        carregarListaPublicacaoUsuario();
        super.onStart();
    }

}
