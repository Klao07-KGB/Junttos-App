package com.example.junttos.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import com.example.junttos.adapter.AdapterListaPublicacao;

import com.example.junttos.fragment.FeedFragment;
import com.example.junttos.helper.PublicacaoDAO;
import com.example.junttos.helper.RecyclerItemClickListener;
import com.example.junttos.helper.SQLite;
import com.example.junttos.model.Publicacao;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.content.Context;
import android.widget.TextView;
import android.widget.Toast;

import com.example.junttos.R;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class ListarPublicacaoUsuarioActivity extends AppCompatActivity {

    private SearchView searchViewPesquisaPublicacao;
    private RecyclerView recyclerViewPesquisaPublicacao;
    //public static SQLite sqLite;
    private AdapterListaPublicacao adapterPesquisaPublicacao;
    private List<Publicacao> listPublicacaoUsuario;
    public  int identUsuario;
 private Publicacao publicacaoSelecionada;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_publicacao_usuario);
        identUsuario = LoginActivity.identUsuario;

        // configurando o toolbar
        Toolbar toolbar =  findViewById(R.id.toolbarPesquisarPublicacao);
        //toolbar.setTitle("Lista de Publicações");
        setSupportActionBar(toolbar);

        // buttao de voltar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close_black);


        // trabalhando em fragment precisa usar view para acessar
        //searchViewPesquisaPublicacao = findViewById(R.id.searchViewPesquisaPublicacao);
        recyclerViewPesquisaPublicacao = findViewById(R.id.recyclerViewPesquisaPublicacao);

        //configuracoes iniciais
        listPublicacaoUsuario = new ArrayList<>();


        //add evento de click do recyclerview
        recyclerViewPesquisaPublicacao.addOnItemTouchListener(new RecyclerItemClickListener(
                getApplicationContext(),
                recyclerViewPesquisaPublicacao,
                new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        // edição do recyclerview

                        // recuperando a publicacao

                        Publicacao publicSelecionada = listPublicacaoUsuario.get(position);

                        //enviar para activity
                        Intent intent = new Intent(ListarPublicacaoUsuarioActivity.this, PublicacaoCadastroActivity.class);
                        intent.putExtra("publicselecionada", publicSelecionada);
                        startActivity(intent);
                    }

                    @Override
                    public void onLongItemClick(View view, int position) {
                        // delete do recyclerview
                        publicacaoSelecionada = listPublicacaoUsuario.get(position);

                        AlertDialog.Builder dialog = new AlertDialog.Builder(ListarPublicacaoUsuarioActivity.this);
                        dialog.setTitle("Confirmar exclusão");
                        dialog.setMessage("Deseja excluir essa publicação: " + publicacaoSelecionada.getTitulo_publicacao() + "?" );
                        dialog.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                PublicacaoDAO publicDAO = new PublicacaoDAO(getApplicationContext());
                                if(publicDAO.deletarPublicacao(publicacaoSelecionada)){
                                    carregarListaPublicacaoUsuario();
                                    Toast.makeText(ListarPublicacaoUsuarioActivity.this,"Publicação removida com sucesso!",Toast.LENGTH_SHORT).show();

                                } else{
                                    Toast.makeText(ListarPublicacaoUsuarioActivity.this,"Erro ao remover publicação!",Toast.LENGTH_SHORT).show();
                                }

                            }
                        });

                        dialog.setNegativeButton("Não", null);
                        dialog.create();
                        dialog.show();
                    }

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    }
                }

        ));



        FloatingActionButton fab = findViewById(R.id.fabPesquisarPublicacao);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),PublicacaoCadastroActivity.class));
               /* Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();*/




            }
        });
    }


    public void carregarListaPublicacaoUsuario(){

      PublicacaoDAO publicDAO = new PublicacaoDAO(getApplicationContext());
      listPublicacaoUsuario = publicDAO.listarPublicacao(identUsuario);

       adapterPesquisaPublicacao = new AdapterListaPublicacao(listPublicacaoUsuario, getApplicationContext());

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerViewPesquisaPublicacao.setLayoutManager(layoutManager);
        recyclerViewPesquisaPublicacao.setHasFixedSize(true);
        recyclerViewPesquisaPublicacao.addItemDecoration(new DividerItemDecoration(getApplicationContext(), LinearLayout.VERTICAL));
        recyclerViewPesquisaPublicacao.setAdapter(adapterPesquisaPublicacao);

    }

    @Override
    public void onStart() {
        carregarListaPublicacaoUsuario();
        super.onStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.pesquisar, menu);

        MenuItem menuItem = menu.findItem(R.id.pesquisa);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(menuItem);

        try {
            AutoCompleteTextView searchTextView = (AutoCompleteTextView) searchView.findViewById(R.id.search_src_text);

            Field mCursorDrawableRes = TextView.class.getDeclaredField("mCursorDrawableRes");
            mCursorDrawableRes.setAccessible(true);
            mCursorDrawableRes.set(searchTextView, R.drawable.cursor_searchview);

        } catch (Exception e) {
        }

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                String text = newText;

                try {
                    adapterPesquisaPublicacao.filter(text);
                }catch (Exception e){

                }
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }
}
