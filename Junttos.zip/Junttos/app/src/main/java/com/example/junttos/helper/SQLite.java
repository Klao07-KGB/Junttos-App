package com.example.junttos.helper;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import java.io.File;

public class SQLite extends SQLiteOpenHelper{

    public static int VERSAO = 3 ;
    public static String NOME_DB = "JUNTTOS" ;
    public static String TABELA_USUARIO = "USUARIO" ;
    public static String TABELA_PUBLICACAO = "PUBLICACAO" ;


     // construtor
    public SQLite(Context context){
        super(context, NOME_DB, null, VERSAO);
    }

  /*     modo antigo
   // construtor
        public SQLite(Context context,
                      String nome,
                      SQLiteDatabase.CursorFactory factory,
                      int versao){
            super(context, nome, factory, versao);
        }*/


     /*   public void queryData(String sql){
            SQLiteDatabase database = getWritableDatabase();
            database.execSQL(sql);
        }


    public static boolean doesDatabaseExist(ContextWrapper context, String dbName) {
        File dbFile = context.getDatabasePath(dbName);
        return dbFile.exists();
    }

        // insert na base

        public void insertPublicacao( String public_titulo, String public_informacao,  String public_dataInicio,  String public_dataFim,  String public_acesso,  String public_observacao,byte[] public_imagem, long public_idUsuario){
            SQLiteDatabase database = getWritableDatabase();
            String sql = "INSERT INTO PUBLICACAO VALUES(NULL,?,?,?,?,?,?,?,?)";

            SQLiteStatement statement = database.compileStatement(sql);
            statement.clearBindings();

            //   statement.bindLong(1, public_id );
            statement.bindString(1, public_titulo );
            statement.bindString(2, public_informacao );
            statement.bindString(3, public_dataInicio );
            statement.bindString(4, public_dataFim );
            statement.bindString(5, public_acesso );
            statement.bindString(6, public_observacao );
            statement.bindBlob(7, public_imagem );
            statement.bindLong(8, public_idUsuario );

            statement.executeInsert();

        }

        // UPDATE NA ABSE
        public void updatePublicacao( long public_id,String public_titulo, String public_informacao,  String public_dataInicio,  String public_dataFim,  String public_acesso,  String public_observacao, byte[] public_imagem, long public_idUsuario ){
            SQLiteDatabase database = getWritableDatabase();
            String sql = "UPDATE PUBLICACAO SET public_titulo = ?, public_informacao = ?,  public_dataInicio= ?,  public_dataFim= ?,   public_acesso= ?,   public_observacao = ?, public_imagem = ? WHERE public_id = ? and public_idUsuario = ?";

            SQLiteStatement statement = database.compileStatement(sql);

            statement.bindLong(1, public_id );
            statement.bindString(2, public_titulo );
            statement.bindString(3, public_informacao );
            statement.bindString(4, public_dataInicio );
            statement.bindString(5, public_dataFim );
            statement.bindString(6, public_acesso );
            statement.bindString(7, public_observacao );
            statement.bindBlob(8, public_imagem );
            statement.bindLong(9, public_idUsuario );

            statement.execute();
            statement.close();

        }

        // delete na base
        public void deletePublicacao( long public_id) {
            SQLiteDatabase database = getWritableDatabase();
            String sql = "DELETE FROM PUBLICACAO WHERE public_id = ?";

            SQLiteStatement statement = database.compileStatement(sql);
            statement.clearBindings();
            statement.bindLong(1, public_id);

            statement.execute();
            statement.close();
        }



}*/


    // listar
    public Cursor getData(String sql){
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql, null);
    }

    public Boolean emptyLogin() {

        String sql = "Select * from USUARIO";

        Cursor cursor = getData(sql);

        int count = 0;

        if ( cursor.moveToFirst() ) {
            count = cursor.getInt(0);
        }

        cursor.close();

        Boolean result = false;
        if (count == 0) {
            result = true;
        }

        return result;
    }

    public void insertlogin(String usu_matricula, String usu_senha, int usu_tipo) {
        SQLiteDatabase database = getWritableDatabase();
        String sql = "INSERT INTO USUARIO VALUES(NULL,?,?,?) ";

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();

        statement.bindString(1, usu_matricula);
        statement.bindString(2, usu_senha);
        statement.bindDouble(3, usu_tipo);

        statement.executeInsert();

    }
        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase){
            String sqlUsuario = "CREATE TABLE IF NOT EXISTS "+ TABELA_USUARIO
                     + " (usu_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                         "usu_matricula VARCHAR , usu_senha VARCHAR, usu_tipo INTEGER );";


            String sqlPublicacao = "CREATE TABLE IF NOT EXISTS "+ TABELA_PUBLICACAO
                    + " ( public_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                      " public_titulo VARCHAR,public_informacao VARCHAR, public_dataInicio VARCHAR, public_dataFim VARCHAR, " +
                      " public_acesso VARCHAR, public_observacao VARCHAR,public_imagem text, public_idUsuario INTEGER);";

            try{
                sqLiteDatabase.execSQL(sqlUsuario);
                sqLiteDatabase.execSQL(sqlPublicacao);
            }catch (Exception e){
                e.printStackTrace();
            }

        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int y){


        }
    }


