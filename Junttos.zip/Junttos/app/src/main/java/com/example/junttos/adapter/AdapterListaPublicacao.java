package com.example.junttos.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.junttos.R;
import com.example.junttos.Util.Funcao;
import com.example.junttos.model.Publicacao;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AdapterListaPublicacao  extends RecyclerView.Adapter<AdapterListaPublicacao.MyViewHolder>{


    private List<Publicacao> listapublicacaousuario;
    private Context context;

    private ArrayList<Publicacao> arraylist;


    //construtor
    public AdapterListaPublicacao(List<Publicacao> listap, Context c) {
        this.listapublicacaousuario = listap;
        this.context = c;
        this.arraylist = new ArrayList<>();
        this.arraylist.addAll(listap);
    }


    @NonNull
    @Override
    public AdapterListaPublicacao.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemListaUsuario = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_pesquisa_publicacao_usuario, parent, false);
        return new AdapterListaPublicacao.MyViewHolder(itemListaUsuario);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Publicacao publicacao = listapublicacaousuario.get(position);
        holder.titulo.setText(publicacao.getTitulo_publicacao());

        if(!publicacao.getCaminhoFoto_publicacao().trim().equals("")){
            Bitmap bitmap = new Funcao().StringToBitMap(publicacao.getCaminhoFoto_publicacao());
            holder.foto.setImageBitmap(bitmap);
        }
    }



    @Override
    public int getItemCount() {
        return listapublicacaousuario.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView foto;
        TextView titulo;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            foto = itemView.findViewById(R.id.imageViewPesquisaPublicacao);
            titulo = itemView.findViewById(R.id.textViewPesquisaPublicacao);
        }
    }

    public void filter(String charText) {

        charText = charText.toLowerCase(Locale.getDefault());
        listapublicacaousuario.clear();

        if (charText.length() == 0) {
            listapublicacaousuario.addAll(arraylist);
        } else {
            for (Publicacao wp : arraylist) {
                if (wp.getTitulo_publicacao().toLowerCase(Locale.getDefault()).contains(charText)) {
                    listapublicacaousuario.add(wp);
                }
            }
        }

        notifyDataSetChanged();
    }

}
